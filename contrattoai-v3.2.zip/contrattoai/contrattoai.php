<?php
/**
 * Plugin Name: ContrattoAI
 * Description: Generatore di contratti con AI — shortcode [contrattoai].
 * Version: 3.2.0
 * Author: Factalex
 * Text Domain: contrattoai
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined('ABSPATH') ) exit;

define('CONTRATTOAI_PATH', plugin_dir_path(__FILE__));
define('CONTRATTOAI_URL',  plugin_dir_url(__FILE__));
define('CONTRATTOAI_VER',  '3.2.0');

require_once CONTRATTOAI_PATH . 'includes/class-contrattoai-plugin.php';
ContrattoAI_Plugin::init();
