<?php
if ( ! defined('ABSPATH') ) exit;

class ContrattoAI_Admin {

  public static function register() {
    add_action('admin_menu', [__CLASS__, 'menu']);
    add_action('admin_init', [__CLASS__, 'settings']);
  }

  public static function menu() {
    add_menu_page(
      __('ContrattoAI', 'contrattoai'),
      'ContrattoAI',
      'manage_options',
      'contrattoai',
      [__CLASS__, 'view_settings'],
      'dashicons-media-text',
      81
    );
  }

  public static function settings() {
    register_setting('contrattoai_group', 'contrattoai_options', [
      'type' => 'array',
      'sanitize_callback' => [__CLASS__, 'sanitize_options'],
      'default' => [],
    ]);

    add_settings_section('contrattoai_ai', __('Provider AI', 'contrattoai'), '__return_false', 'contrattoai');

    add_settings_field('ai_provider', __('Provider', 'contrattoai'), function(){
      $opts = get_option('contrattoai_options', []);
      $val = $opts['ai_provider'] ?? 'openai';
      echo '<select name="contrattoai_options[ai_provider]">';
      echo '<option value="openai" ' . selected($val, 'openai', false) . '>OpenAI</option>';
      echo '</select>';
    }, 'contrattoai', 'contrattoai_ai');

    add_settings_field('openai_api_key', __('OpenAI API Key', 'contrattoai'), function(){
      $opts = get_option('contrattoai_options', []);
      $val = $opts['openai_api_key'] ?? '';
      echo '<input type="password" style="width:420px" name="contrattoai_options[openai_api_key]" value="' . esc_attr($val) . '" placeholder="sk-..." />';
    }, 'contrattoai', 'contrattoai_ai');

    add_settings_field('openai_model', __('Modello', 'contrattoai'), function(){
      $opts = get_option('contrattoai_options', []);
      $val = $opts['openai_model'] ?? 'gpt-4o-mini';
      echo '<input type="text" style="width:260px" name="contrattoai_options[openai_model]" value="' . esc_attr($val) . '" />';
      echo '<p class="description">'. esc_html__('Esempi: gpt-4o-mini, gpt-4o, gpt-4.1, ecc.', 'contrattoai') .'</p>';
    }, 'contrattoai', 'contrattoai_ai');
  }

  public static function sanitize_options($opts) {
    $o = [];
    $o['ai_provider'] = 'openai';
    if (!empty($opts['openai_api_key'])) { $o['openai_api_key'] = sanitize_text_field($opts['openai_api_key']); }
    if (!empty($opts['openai_model']))   { $o['openai_model']   = sanitize_text_field($opts['openai_model']); }
    return $o;
  }

  public static function view_settings() {
    echo '<div class="wrap"><h1>ContrattoAI</h1>';
    echo '<form method="post" action="options.php">';
    settings_fields('contrattoai_group');
    do_settings_sections('contrattoai');
    submit_button();
    echo '</form></div>';
  }
}
