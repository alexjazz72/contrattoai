<div class="wrap">
  <h1>Impostazioni ContrattoAI</h1>
  <p>Configura la tua chiave e il modello OpenAI.</p>
  <hr/>
  <form method="post" action="options.php">
    <?php settings_fields('contrattoai_group'); ?>
    <?php do_settings_sections('contrattoai'); ?>
    <?php submit_button(); ?>
  </form>
  <p><em>Nota:</em> la generazione passa da <code>/wp-json/contrattoai/v1/generate</code> e la chiave non viene mai esposta al client.</p>
</div>
