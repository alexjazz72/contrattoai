<?php
if ( ! defined('ABSPATH') ) exit;

require_once CONTRATTOAI_PATH . 'includes/class-contrattoai-assets.php';
require_once CONTRATTOAI_PATH . 'includes/class-contrattoai-shortcodes.php';
require_once CONTRATTOAI_PATH . 'includes/class-contrattoai-generator.php';
require_once CONTRATTOAI_PATH . 'includes/class-contrattoai-rest.php';
require_once CONTRATTOAI_PATH . 'includes/helpers.php';
require_once CONTRATTOAI_PATH . 'admin/class-contrattoai-admin.php';

class ContrattoAI_Plugin {
  public static function init() {
    add_action('init', [__CLASS__, 'load_textdomain']);
    add_action('plugins_loaded', [__CLASS__, 'boot']);
  }

  public static function load_textdomain() {
    load_plugin_textdomain('contrattoai', false, 'contrattoai/languages');
  }

  public static function boot() {
    ContrattoAI_Shortcodes::register();
    ContrattoAI_REST::register_routes();
    ContrattoAI_Admin::register();
  }
}
