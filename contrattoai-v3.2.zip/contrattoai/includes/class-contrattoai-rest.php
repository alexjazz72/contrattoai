<?php
if ( ! defined('ABSPATH') ) exit;

class ContrattoAI_REST {
  public static function register_routes() {
    add_action('rest_api_init', function () {
      register_rest_route('contrattoai/v1', '/send', [
        'methods'  => 'POST',
        'callback' => [__CLASS__, 'send_email'],
        'permission_callback' => [__CLASS__, 'permission'],
      ]);
      register_rest_route('contrattoai/v1', '/generate', [
        'methods'  => 'POST',
        'callback' => [__CLASS__, 'generate'],
        'permission_callback' => [__CLASS__, 'permission'],
      ]);
    });
  }

  public static function permission() {
    $nonce = $_SERVER['HTTP_X_WP_NONCE'] ?? '';
    return wp_verify_nonce( $nonce, 'wp_rest' );
  }

  private static function rate_ok() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $key = 'contrattoai_rate_' . md5($ip);
    $count = (int) get_transient($key);
    if ($count > 9) return false; // 10/min complessivi (generate+send)
    set_transient($key, $count + 1, 60);
    return true;
  }

  public static function send_email( WP_REST_Request $req ) {
    if ( ! self::rate_ok() ) {
      return new WP_REST_Response(['success'=>false,'error'=>'Too Many Requests'], 429);
    }

    $email = sanitize_email( $req->get_param('email') );
    $contenuto_raw = (string) $req->get_param('contenuto');
    $contenuto = wp_strip_all_tags( $contenuto_raw );

    if ( ! is_email($email) || empty($contenuto) ) {
      return new WP_REST_Response(['success'=>false,'error'=>'Bad Request'], 400);
    }

    $subject = sprintf( __('Il tuo contratto - %s', 'contrattoai'), get_bloginfo('name') );
    $ok = wp_mail($email, $subject, $contenuto);
    return new WP_REST_Response(['success'=>$ok], $ok ? 200 : 500);
  }

  public static function generate( WP_REST_Request $req ) {
    if ( ! self::rate_ok() ) {
      return new WP_REST_Response(['success'=>false,'error'=>'Too Many Requests'], 429);
    }

    $args = [
      'tipo' => $req->get_param('tipo'),
      'stile' => $req->get_param('stile'),
      'parti' => $req->get_param('parti'),
      'oggetto' => $req->get_param('oggetto'),
      'durata' => $req->get_param('durata'),
      'dataDecorrenza' => $req->get_param('dataDecorrenza'),
      'compenso' => $req->get_param('compenso'),
      'foro' => $req->get_param('foro'),
      'note' => $req->get_param('note'),
    ];

    $result = ContrattoAI_Generator::generate_contract($args);
    if ( is_wp_error($result) ) {
      $status = $result->get_error_data('status') ?: 500;
      return new WP_REST_Response(['success'=>false,'error'=>$result->get_error_message()], $status);
    }
    return new WP_REST_Response(['success'=>true,'contratto'=>$result], 200);
  }
}
