<?php
if ( ! defined('ABSPATH') ) exit;

class ContrattoAI_Assets {
  public static function enqueue_frontend() {
    $css = CONTRATTOAI_PATH . 'assets/css/frontend.css';
    $js  = CONTRATTOAI_PATH . 'assets/js/frontend.js';

    wp_enqueue_style(
      'contrattoai-frontend',
      CONTRATTOAI_URL . 'assets/css/frontend.css',
      [],
      file_exists($css) ? filemtime($css) : CONTRATTOAI_VER
    );

    wp_enqueue_script(
      'contrattoai-frontend',
      CONTRATTOAI_URL . 'assets/js/frontend.js',
      ['wp-i18n'],
      file_exists($js) ? filemtime($js) : CONTRATTOAI_VER,
      true
    );
    if ( function_exists('wp_script_add_data') ) {
      wp_script_add_data('contrattoai-frontend', 'type', 'module');
    }

    wp_set_script_translations('contrattoai-frontend', 'contrattoai', CONTRATTOAI_PATH . 'languages');

    wp_localize_script('contrattoai-frontend', 'ContrattoAIData', [
      'restUrl' => esc_url_raw( rest_url('contrattoai/v1') ),
      'nonce'   => wp_create_nonce('wp_rest'),
    ]);
  }
}
