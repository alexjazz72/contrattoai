<?php
if ( ! defined('ABSPATH') ) exit;

function contrattoai_escape_text( $text ) {
  return wp_strip_all_tags( (string) $text );
}
