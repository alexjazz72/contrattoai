<?php
if ( ! defined('ABSPATH') ) exit;

class ContrattoAI_Generator {

  public static function get_option($key, $default = '') {
    $opts = get_option('contrattoai_options', []);
    return isset($opts[$key]) ? $opts[$key] : $default;
  }

  public static function prompt_for($tipo, $stile, $parti, $oggetto, $durata, $extra = []) {
    $tone = ($stile === 'semplificato')
      ? 'Scrivi in italiano semplice, frasi corte, senza gergo.'
      : 'Scrivi in italiano formale e professionale, registro giuridico.';

    $template = "Sei un giurista italiano. Redigi un contratto completo, coerente e valido in Italia.
" .
      "REGOLE:
- Niente placeholder tipo [NOME] nel risultato finale.
- Struttura con articoli e clausole numerate.
- Inserisci data e luogo solo se forniti.
- Evita riferimenti normativi superflui; usa clausole standard.
- Restituisci SOLO testo puro (niente HTML o Markdown).

";

    $tipo_line = "TIPO: {$tipo}
";
    $inputs = "PARTI: {$parti}
OGGETTO: {$oggetto}
DURATA: {$durata}
";
    if (!empty($extra)) {
      foreach ($extra as $k=>$v) { if ($v) { $inputs .= strtoupper($k).": ".$v."\n"; } }
    }

    $specifiche = "";
    switch ( strtolower($tipo) ) {
      case 'contratto di locazione abitativa':
        $specifiche = "- Includi oggetto, canone, deposito, durata e recesso; manutenzione ordinaria/straordinaria; consegna e stato dell'immobile; eventuale cedolare secca come opzione.
";
        break;
      case 'accordo di riservatezza (nda)':
        $specifiche = "- Definisci informazioni riservate, obblighi delle parti, durata della riservatezza, esclusioni, restituzione/ distruzione documenti, foro competente.
";
        break;
      case 'contratto di prestazione occasionale':
        $specifiche = "- Indica natura occasionale, compenso, termini di pagamento, diritti d'autore se pertinenti, assenza di subordinazione, responsabilità, foro competente.
";
        break;
      case 'contratto di consulenza':
        $specifiche = "- Descrivi ambito della consulenza, obiettivi, compenso (a ore o a progetto), riservatezza, IP, termini e recesso, risoluzione delle controversie.
";
        break;
      case 'compravendita beni mobili':
        $specifiche = "- Specifica descrizione beni, prezzo, consegna e passaggio del rischio, garanzie, legge applicabile e foro competente.
";
        break;
      default:
        $specifiche = "- Struttura classica con premesse, definizioni se utili, clausole numerate e chiusura con firme.
";
    }

    $tone_line = "TONO: {$tone}
";
    $closing = "RESTITUISCI SOLO TESTO PURO.
";

    return $template . $tipo_line . $tone_line . $inputs . $specifiche . $closing;
  }

  public static function generate_contract($args) {
    $tipo    = sanitize_text_field($args['tipo'] ?? '');
    $stile   = sanitize_text_field($args['stile'] ?? 'formale');
    $parti   = wp_strip_all_tags($args['parti'] ?? '');
    $oggetto = wp_strip_all_tags($args['oggetto'] ?? '');
    $durata  = wp_strip_all_tags($args['durata'] ?? '');

    $extra = [
      'decorrenza' => wp_strip_all_tags($args['dataDecorrenza'] ?? ''),
      'compenso'   => wp_strip_all_tags($args['compenso'] ?? ''),
      'foro'       => wp_strip_all_tags($args['foro'] ?? ''),
      'note'       => wp_strip_all_tags($args['note'] ?? ''),
    ];

    $prompt = self::prompt_for($tipo, $stile, $parti, $oggetto, $durata, $extra);

    $provider = self::get_option('ai_provider', 'openai');
    if ($provider === 'openai') {
      $api_key = self::get_option('openai_api_key', '');
      $model   = self::get_option('openai_model', 'gpt-4o-mini');
      if ( empty($api_key) ) {
        return new WP_Error('no_key', __('Chiave OpenAI mancante. Configura il plugin.', 'contrattoai'), ['status'=>500]);
      }
      $resp = wp_remote_post('https://api.openai.com/v1/chat/completions', [
        'headers' => [
          'Authorization' => 'Bearer ' . $api_key,
          'Content-Type'  => 'application/json',
        ],
        'timeout' => 60,
        'body' => wp_json_encode([
          'model' => $model,
          'messages' => [
            ['role'=>'system', 'content'=>'Sei un assistente giuridico che redige contratti in Italia. Restituisci solo testo puro.'],
            ['role'=>'user', 'content'=>$prompt],
          ],
          'temperature' => 0.2,
        ]),
      ]);
      if ( is_wp_error($resp) ) return $resp;
      $code = wp_remote_retrieve_response_code($resp);
      $body = json_decode( wp_remote_retrieve_body($resp), true );
      if ($code !== 200 || empty($body['choices'][0]['message']['content'])) {
        return new WP_Error('ai_error', __('Errore dal provider AI.', 'contrattoai'), ['status'=>500, 'body'=>$body]);
      }
      $text = $body['choices'][0]['message']['content'];
      // Solo testo
      return wp_strip_all_tags($text);
    }

    // Fallback mock (se provider sconosciuto): utile in dev
    $mock = "CONTRATTO
Tipo: {$tipo}
Parti: {$parti}
Oggetto: {$oggetto}
Durata: {$durata}

[Bozza generata - configura l'API in Bacheca → ContrattoAI]";
    return $mock;
  }
}
