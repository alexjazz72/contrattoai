<?php
if ( ! defined('ABSPATH') ) exit;

class ContrattoAI_Shortcodes {
  public static function register() {
    add_shortcode('contrattoai', [__CLASS__, 'render']);
  }

  public static function render($atts = []) {
    if ( class_exists('ContrattoAI_Assets') ) {
      ContrattoAI_Assets::enqueue_frontend();
    }
    ob_start();
    include CONTRATTOAI_PATH . 'templates/frontend/widget.php';
    return ob_get_clean();
  }
}
