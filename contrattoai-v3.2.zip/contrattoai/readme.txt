=== ContrattoAI ===
Contributors: factalex
Tags: contracts, ai, generator
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 3.2.0
License: GPLv2 or later

Generatore contratti con AI. Shortcode: [contrattoai]

== Description ==
- Shortcode che inserisce un widget per generare contratti testuali.
- /generate: proxy server-side verso OpenAI (chiave in Bacheca -> ContrattoAI).
- Invio via email (REST con nonce + rate-limit).
- Stampa/PDF sicura (escape HTML).

== Installation ==
1. Carica la cartella `contrattoai` in `wp-content/plugins/`.
2. Attiva il plugin.
3. Inserisci `[contrattoai]` in una pagina.
4. Bacheca → ContrattoAI: imposta chiave e modello.

== Changelog ==
= 3.2.0 =
* Aggiunto endpoint /generate con proxy verso OpenAI e impostazioni admin.
