<div id="contratto-ai-container" class="contrattoai-widget">
  <div class="ai-card">
    <h2 class="ai-title">&#x1F9E0; ContrattoAI</h2>
    <p class="ai-subtitle">Genera contratti personalizzati con AI. I dati sono trattati localmente; l'invio a terzi avviene solo quando premi "Genera".</p>

    <label for="ai-tipo"><strong>&#x1F4C1; Tipo di contratto</strong></label>
    <select id="ai-tipo" class="ai-input">
      <option>Contratto di locazione abitativa</option>
      <option>Contratto di prestazione occasionale</option>
      <option>Accordo di riservatezza (NDA)</option>
      <option>Contratto di consulenza</option>
      <option>Compravendita beni mobili</option>
      <option>Altro (specifica nell'oggetto)</option>
    </select>

    <label for="ai-stile"><strong>&#x1F3AF; Stile</strong></label>
    <select id="ai-stile" class="ai-input">
      <option value="formale">Formale e professionale</option>
      <option value="semplificato">Semplificato e comprensibile</option>
    </select>

    <label for="ai-parti"><strong>&#x1F465; Parti coinvolte</strong></label>
    <textarea id="ai-parti" class="ai-input" rows="3" placeholder="Es: Mario Rossi ... e Giulia Verdi ..."></textarea>

    <label for="ai-oggetto"><strong>&#x1F4CC; Oggetto</strong></label>
    <textarea id="ai-oggetto" class="ai-input" rows="3" placeholder="Descrivi in modo sintetico l'oggetto del contratto"></textarea>

    <label for="ai-durata"><strong>&#x23F3; Durata</strong></label>
    <input id="ai-durata" class="ai-input" placeholder="Es: 12 mesi a partire dal 01/05/2026" />

    <details class="ai-details">
      <summary>➕ Dettagli opzionali</summary>
      <div class="ai-grid">
        <label>Decorrenza <input id="ai-decorrenza" type="date" class="ai-input"></label>
        <label>Compenso/Valore <input id="ai-compenso" class="ai-input" placeholder="Es: € 1.000 una tantum"></label>
        <label>Foro competente <input id="ai-foro" class="ai-input" placeholder="Es: Foro di Roma"></label>
        <label>Note <textarea id="ai-note" class="ai-input" rows="2" placeholder="Clausole extra"></textarea></label>
      </div>
    </details>

    <button id="ai-genera" class="ai-btn primary">&#x2728; Genera</button>

    <div id="ai-output" class="ai-output" hidden>
      <h3>&#x1F4C4; Contratto generato</h3>
      <textarea id="ai-contratto" rows="18" class="ai-text"></textarea>

      <div class="ai-actions">
        <button id="ai-doc" class="ai-btn">&#x1F4DD; Scarica .doc</button>
        <button id="ai-pdf" class="ai-btn">&#x1F5A8;&#xFE0F; Stampa / PDF</button>
      </div>

      <div class="ai-email">
        <input id="ai-email" class="ai-input" type="email" placeholder="La tua email" />
        <button id="ai-send" class="ai-btn warn">&#x1F4E7; Invia via email</button>
      </div>
      <p id="ai-status" class="ai-status" aria-live="polite"></p>
    </div>
  </div>
</div>
