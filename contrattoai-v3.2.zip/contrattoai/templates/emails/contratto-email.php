<?php
echo esc_html( $args['contenuto'] ?? '' );
