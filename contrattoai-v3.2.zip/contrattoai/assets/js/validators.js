export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(email || '').trim());
}
// TODO: CF/P.IVA reali in uno sprint successivo
export function isValidCF(cf) {
  return !!(cf && cf.trim().length >= 11);
}
export function isValidPIVA(piva) {
  return !!(piva && piva.trim().length === 11 && /^\d+$/.test(piva));
}
