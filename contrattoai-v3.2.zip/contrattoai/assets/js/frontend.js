import { safeFetch, setBusy, printAsPDF } from './api.js';
import { isValidEmail } from './validators.js';

(function(){
  function $(id){ return document.getElementById(id); }
  document.addEventListener('DOMContentLoaded', () => {
    const btn = $('ai-genera');
    const out = $('ai-output');
    const txt = $('ai-contratto');
    const status = $('ai-status');

    btn?.addEventListener('click', async () => {
      const payload = {
        tipo: $('ai-tipo').value,
        stile: $('ai-stile').value,
        parti: $('ai-parti').value.trim(),
        oggetto: $('ai-oggetto').value.trim(),
        durata: $('ai-durata').value.trim(),
        dataDecorrenza: $('ai-decorrenza')?.value || '',
        compenso: $('ai-compenso')?.value || '',
        foro: $('ai-foro')?.value || '',
        note: $('ai-note')?.value || ''
      };

      if(!payload.parti || !payload.oggetto || !payload.durata){
        alert('Completa: Parti, Oggetto, Durata.');
        return;
      }

      out.hidden = false;
      txt.value = '⏳ Generazione in corso...';
      setBusy(btn, true, '⏳ Generazione...', '✨ Genera');

      try {
        const data = await safeFetch(ContrattoAIData.restUrl + '/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': ContrattoAIData.nonce },
          body: JSON.stringify(payload)
        });
        txt.value = data?.contratto || 'Nessun contenuto ricevuto.';
      } catch (e) {
        txt.value = 'Errore: ' + (e.message || e);
      } finally {
        setBusy(btn, false, null, '✨ Genera');
      }
    });

    $('ai-doc')?.addEventListener('click', () => {
      const blob = new Blob([$('ai-contratto').value], { type: 'application/msword' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'contratto.doc';
      a.click();
      URL.revokeObjectURL(a.href);
    });

    $('ai-pdf')?.addEventListener('click', () => {
      printAsPDF($('ai-contratto').value);
    });

    $('ai-send')?.addEventListener('click', async () => {
      const email = $('ai-email').value.trim();
      if(!isValidEmail(email)){
        status.textContent = 'Email non valida.';
        return;
      }
      status.textContent = '📤 Invio in corso...';
      try {
        const data = await safeFetch(ContrattoAIData.restUrl + '/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': ContrattoAIData.nonce },
          body: JSON.stringify({ email, contenuto: $('ai-contratto').value })
        });
        status.textContent = data?.success ? '✅ Inviato!' : '❌ Errore di invio.';
      } catch(e) {
        status.textContent = '❌ ' + (e.message || 'Errore');
      }
    });
  });
})();
