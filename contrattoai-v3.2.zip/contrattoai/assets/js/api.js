export async function safeFetch(url, options = {}) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const err = new Error(`HTTP ${res.status}`);
    err.status = res.status;
    err.body = text;
    throw err;
  }
  const ct = res.headers.get('content-type') || '';
  return ct.includes('application/json') ? res.json() : res.text();
}

export function setBusy(btn, busy, labelBusy, labelIdle) {
  if (!btn) return;
  btn.disabled = !!busy;
  if (labelBusy && labelIdle) {
    btn.dataset.idle = labelIdle;
    btn.textContent = busy ? labelBusy : labelIdle;
  }
}

export function escapeHTML(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function printAsPDF(text) {
  const escaped = escapeHTML(text).replace(/\n/g, '<br>');
  const win = window.open('', '_blank', 'noopener,noreferrer');
  if (!win) return;
  win.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Contratto</title>
  <style>body{font-family:ui-sans-serif;line-height:1.5;padding:24px}</style></head><body>
  <div>${escaped}</div><script>window.onload=()=>setTimeout(()=>window.print(),50)<\/script></body></html>`);
  win.document.close();
}
